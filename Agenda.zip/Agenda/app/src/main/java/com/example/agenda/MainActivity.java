package com.example.agenda;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.LinkedList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    int iterador;
    List<persona> personas = iniciaPersonas();

    EditText Nombre;
    EditText Apellidos;
    EditText teléfono;

    Button izda;
    Button derecha;
    Button centro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         Nombre = (EditText) findViewById(R.id.Nombre);
         Apellidos = (EditText) findViewById(R.id.Apellidos);
         teléfono = (EditText) findViewById(R.id.teléfono);

         izda = (Button) findViewById(R.id.izqda);
         derecha = (Button) findViewById(R.id.derecha);
         centro = (Button) findViewById(R.id.centro);

         Nombre.addTextChangedListener(new TextWatcher() {
             @Override
             public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

             }

             @Override
             public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

             }

             @Override
             public void afterTextChanged(Editable editable) {
                 if(iterador<personas.size()){
                     persona actual = personas.get(iterador);
                     centro.setEnabled(
                             !Nombre.getText().toString().equals(actual.getNombre())
                     );
                 }
                 else{
                     centro.setEnabled(true);
                 }

             }
         });

         Apellidos.addTextChangedListener(new TextWatcher() {
             @Override
             public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

             }

             @Override
             public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

             }

             @Override
             public void afterTextChanged(Editable editable) {
                 if(iterador<personas.size()){
                     persona actual = personas.get(iterador);
                     centro.setEnabled(
                             !Apellidos.getText().toString().equals(actual.getApellido())
                     );
                 }
                 else{
                     centro.setEnabled(true);
                 }

             }
         });

         teléfono.addTextChangedListener(new TextWatcher() {
             @Override
             public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

             }

             @Override
             public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

             }

             @Override
             public void afterTextChanged(Editable editable) {
                 if(iterador<personas.size()){
                     persona actual = personas.get(iterador);
                     centro.setEnabled(
                             !teléfono.getText().toString().equals(actual.getTelefono())
                     );
                 }
                 else{
                     centro.setEnabled(true);
                 }

             }
         });

        derecha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(iterador<personas.size()-1) {
                    iterador++;
                    actualizaUI();
                    izda.setEnabled(true);

                }
                else{
                    iterador++;
                    Nombre.setText("");
                    Apellidos.setText("");
                    teléfono.setText("");
                    derecha.setEnabled(false);
                }


            }
        });
        izda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(iterador!=0) {
                    iterador--;
                    actualizaUI();
                    derecha.setEnabled(true);
                }
            }
        });

        centro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (iterador == personas.size()){
                    personas.add((new persona(Nombre.getText().toString(),Apellidos.getText().toString(),teléfono.getText().toString())));
                    derecha.setEnabled(true);
                    actualizaUI();
                }
            }
        });

        personas = iniciaPersonas();
        iterador = 0;
        actualizaUI();

    }



    private void actualizaUI() {
        persona actual = personas.get(iterador);
        Nombre.setText(actual.getNombre());
        Apellidos.setText(actual.getApellido());
        teléfono.setText(actual.getTelefono());
        if (iterador==0) {
            izda.setEnabled(false);
        }

    }

j
    private List<persona> iniciaPersonas() {
        List<persona> personas = new LinkedList<>();
        personas.add(new persona("Karlos","Arguiñano","12346579"));
        personas.add(new persona("Pepe","Viyuela","654987321"));
        personas.add(new persona("Paco","Sanz","698754321"));
        personas.add(new persona("Rafa","Mora","678912345"));
        personas.add(new persona("Jorge Javier","Vazquez","789541236"));

        return personas;

    }

}
